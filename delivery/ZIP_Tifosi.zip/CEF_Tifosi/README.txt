Archive : Tifosi.zip
Contenu : Projet pédagogique — base de données MySQL « Tifosi »

Projet : Tifosi (devoir CEF – MySQL)
Version livrée : v1.0.0
Date : juin 2025

Dossier principal : CEF_Tifosi/
Inclus :
- Scripts SQL de création (`import_tifosi.sql`) et insertion (`insert_data.sql`)
- Données tests (`queries-test.sql`)
- Sauvegarde (`backup_tifosi.sql`)
- Guide d’exploitation (`README_livraison.md`)
- Données CSV (`datas-csv/`)

➡️ Ouvrir le fichier README_livraison.md pour connaître la marche à suivre.
